Model Information:
* title:	Monobloc - Plastic Garden Chair
* source:	https://sketchfab.com/3d-models/monobloc-plastic-garden-chair-261d81ec28d845eba3bb7373768c60c5
* author:	Pyromma-GS (https://sketchfab.com/Pyromma-GS)

Model License:
* license type:	CC-BY-SA-4.0 (http://creativecommons.org/licenses/by-sa/4.0/)
* requirements:	Author must be credited. Modified versions must have the same license. Commercial use is allowed.

If you use this 3D model in your project be sure to copy paste this credit wherever you share it:
This work is based on "Monobloc - Plastic Garden Chair" (https://sketchfab.com/3d-models/monobloc-plastic-garden-chair-261d81ec28d845eba3bb7373768c60c5) by Pyromma-GS (https://sketchfab.com/Pyromma-GS) licensed under CC-BY-SA-4.0 (http://creativecommons.org/licenses/by-sa/4.0/)