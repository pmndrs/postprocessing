Model Information:
* title:	Crystal stone (rock)
* source:	https://sketchfab.com/3d-models/crystal-stone-rock-1ad829e2f464446fa4945562ab611255
* author:	GenEugene (https://sketchfab.com/geneugene)

Model License:
* license type:	CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
* requirements:	Author must be credited. No commercial use.

If you use this 3D model in your project be sure to copy paste this credit wherever you share it:
This work is based on "Crystal stone (rock)" (https://sketchfab.com/3d-models/crystal-stone-rock-1ad829e2f464446fa4945562ab611255) by GenEugene (https://sketchfab.com/geneugene) licensed under CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0/)