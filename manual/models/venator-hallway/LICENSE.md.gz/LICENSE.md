Model Information:
* title:	Star Wars: The Clone Wars: Venator Prefab
* source:	https://sketchfab.com/3d-models/star-wars-the-clone-wars-venator-prefab-8a1e1760391c4ac6a50373c2bf5efa2e
* author:	ShineyFX (https://sketchfab.com/ShineyFX)

Model License:
* license type:	CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
* requirements:	Author must be credited. Commercial use is allowed.

If you use this 3D model in your project be sure to copy paste this credit wherever you share it:
This work is based on "Star Wars: The Clone Wars: Venator Prefab" (https://sketchfab.com/3d-models/star-wars-the-clone-wars-venator-prefab-8a1e1760391c4ac6a50373c2bf5efa2e) by ShineyFX (https://sketchfab.com/ShineyFX) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)