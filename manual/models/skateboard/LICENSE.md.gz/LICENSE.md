Model Information:
* title:	Skateboard
* source:	https://sketchfab.com/3d-models/skateboard-daba6e30f78d4604b5167b2f83b0d162
* author:	George.Levchenko (https://sketchfab.com/George.Levchenko)

Model License:
* license type:	CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
* requirements:	Author must be credited. Commercial use is allowed.

If you use this 3D model in your project be sure to copy paste this credit wherever you share it:
This work is based on "Skateboard" (https://sketchfab.com/3d-models/skateboard-daba6e30f78d4604b5167b2f83b0d162) by George.Levchenko (https://sketchfab.com/George.Levchenko) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)