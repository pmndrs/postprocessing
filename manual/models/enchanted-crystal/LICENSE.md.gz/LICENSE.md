Model Information:
* title:	Enchanted Crystal
* source:	https://sketchfab.com/3d-models/enchanted-crystal-6b01945a041d4ed3b80e14274f0e68c9
* author:	TheTallOne (https://sketchfab.com/TheTallOne)

Model License:
* license type:	CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
* requirements:	Author must be credited. Commercial use is allowed.

If you use this 3D model in your project be sure to copy paste this credit wherever you share it:
This work is based on "Enchanted Crystal" (https://sketchfab.com/3d-models/enchanted-crystal-6b01945a041d4ed3b80e14274f0e68c9) by TheTallOne (https://sketchfab.com/TheTallOne) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)