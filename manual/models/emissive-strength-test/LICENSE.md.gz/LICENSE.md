Model and textures by Ed Mackey.
Copyright 2022 Analytical Graphics, Inc. CC-BY 4.0 https://creativecommons.org/licenses/by/4.0/
