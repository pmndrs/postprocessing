Model Information:
* title:	Sci Fi Hallway FREE
* source:	https://sketchfab.com/3d-models/sci-fi-hallway-free-44fd25310d2240908027390a078368e1
* author:	Seesha (https://sketchfab.com/Seesha)

Model License:
* license type:	CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
* requirements:	Author must be credited. Commercial use is allowed.

If you use this 3D model in your project be sure to copy paste this credit wherever you share it:
This work is based on "Sci Fi Hallway FREE" (https://sketchfab.com/3d-models/sci-fi-hallway-free-44fd25310d2240908027390a078368e1) by Seesha (https://sketchfab.com/Seesha) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)