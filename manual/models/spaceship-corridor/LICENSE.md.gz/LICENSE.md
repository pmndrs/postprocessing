Model Information:
* title:	Spaceship Corridor
* source:	https://sketchfab.com/3d-models/spaceship-corridor-1cdd1db557b8428892af4773bdada913
* author:	the_table (https://sketchfab.com/the_table)

Model License:
* license type:	CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
* requirements:	Author must be credited. Commercial use is allowed.

If you use this 3D model in your project be sure to copy paste this credit wherever you share it:
This work is based on "Spaceship Corridor" (https://sketchfab.com/3d-models/spaceship-corridor-1cdd1db557b8428892af4773bdada913) by the_table (https://sketchfab.com/the_table) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)