Model Information:
* title:	Chocolate Bar
* source:	https://sketchfab.com/3d-models/chocolate-bar-0d2dc2567a784fd28e9cb9a43c9f6505
* author:	Fridge (https://sketchfab.com/youssefdarwish01)

Model License:
* license type:	CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
* requirements:	Author must be credited. Commercial use is allowed.

If you use this 3D model in your project be sure to copy paste this credit wherever you share it:
This work is based on "Chocolate Bar" (https://sketchfab.com/3d-models/chocolate-bar-0d2dc2567a784fd28e9cb9a43c9f6505) by Fridge (https://sketchfab.com/youssefdarwish01) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)