# License Information

This work is marked with CC0 1.0.

To view a copy of this license, visit https://creativecommons.org/publicdomain/zero/1.0/

# Texture Information

Generated with https://tools.wwwtyro.net/space-3d/index.html
