Copyright © 2022 Raoul van Rüschen

Resources in this folder are licensed under the Creative Commons Attribution 4.0 International License unless specified otherwise. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/4.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.
